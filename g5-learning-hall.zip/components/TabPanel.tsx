// components/TabPanel.tsx
import { motion } from 'framer-motion';

interface TabPanelProps {
  children: React.ReactNode;
  id: string; // The unique key for this tab
}

export default function TabPanel({ children, id }: TabPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  );
}