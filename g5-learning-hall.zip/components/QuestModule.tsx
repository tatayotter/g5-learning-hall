// components/QuestModule.tsx
import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { CharacterStats } from '@/hooks/useWeeklyData';

interface QuizQuestion {
  question: string;
  options: string[];
  correct_answer: string;
}

interface QuestModuleProps {
  questName: string;
  questKey: string;
  questData: any;
  currentStats: CharacterStats;
  attemptsSoFar: number;
  isMastered: boolean;
  onQuizSubmit: (isPerfect: boolean, newAttempts: number, newStats: CharacterStats, xpEarned: number, goldEarned: number) => void;
  onExit: () => void;
  hideContent?: boolean;
}

function calculateReward(attempts: number) {
  const safeAttempts = Number.isFinite(attempts) && attempts > 0 ? attempts : 1;
  const multiplier = Math.max(1 - 0.1 * (safeAttempts - 1), 0.5);
  return {
    xp: Math.round(200 * multiplier),
    gold: Math.round(50 * multiplier)
  };
}

export default function QuestModule({ questName, questKey, questData, currentStats, attemptsSoFar, isMastered, onQuizSubmit, onExit, hideContent = false }: QuestModuleProps) {
  // Defensive: guarantee this is always a real number, never undefined/NaN
  const safeAttemptsSoFar = Number.isFinite(attemptsSoFar) ? attemptsSoFar : 0;

  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [lastResult, setLastResult] = useState<{ isPerfect: boolean; score: number; total: number; xp: number; gold: number; attemptNumber: number } | null>(null);

  const content = typeof questData === 'string'
    ? questData
    : questData?.content || questData?.summary_markdown || "### Welcome to this module!\n\nRead the material carefully before proceeding.";

  const quiz: QuizQuestion[] = questData?.quiz || [];

  const handleSelect = (qIndex: number, option: string) => {
    if (submitted) return;
    setSelectedAnswers({ ...selectedAnswers, [qIndex]: option });
  };

  const handleSubmitQuiz = () => {
    const total = quiz.length;
    let correctCount = 0;
    quiz.forEach((q, i) => {
      if (selectedAnswers[i] === q.correct_answer) correctCount++;
    });
    const isPerfect = total > 0 && correctCount === total;
    const newAttempts = safeAttemptsSoFar + 1;

    let newStats = { ...currentStats };
    let reward = { xp: 0, gold: 0 };

    if (isPerfect) {
      reward = calculateReward(newAttempts);
      newStats.xp += reward.xp;
      newStats.gold += reward.gold;

      let currentXp = newStats.xp;
      let currentLvl = newStats.level;
      while (currentXp >= (500 + currentLvl * 100)) {
        currentXp -= (500 + currentLvl * 100);
        currentLvl += 1;
      }
      newStats.xp = currentXp;
      newStats.level = currentLvl;
    }

    setSubmitted(true);
    setLastResult({ isPerfect, score: correctCount, total, xp: reward.xp, gold: reward.gold, attemptNumber: newAttempts });
    onQuizSubmit(isPerfect, newAttempts, newStats, reward.xp, reward.gold);
  };

  const handleRetry = () => {
    setSelectedAnswers({});
    setSubmitted(false);
    setLastResult(null);
  };

  const allAnswered = quiz.length > 0 && quiz.every((_, i) => selectedAnswers[i] !== undefined);

  // --- ALREADY MASTERED: locked recap view ---
  if (isMastered) {
    const recap = calculateReward(safeAttemptsSoFar);
    return (
      <div className="bg-green-900/20 border border-green-800 p-8 rounded-xl text-center">
        <h2 className="text-3xl font-bold text-green-400 mb-4 font-display">✅ Quest Completed!</h2>
        <p className="text-gray-400 mb-2">Mastered in {safeAttemptsSoFar || 1} attempt{safeAttemptsSoFar !== 1 ? 's' : ''}.</p>
        <p className="text-xl mb-6">You earned <span className="font-bold text-blue-400 font-mono">{recap.xp} XP</span> and <span className="font-bold text-yellow-400 font-mono">{recap.gold} Gold</span>.</p>
        <button
          onClick={onExit}
          className="bg-neutral-800 hover:bg-neutral-700 text-white font-bold py-3 px-6 rounded transition-colors"
        >
          Return to Campaign Map
        </button>
      </div>
    );
  }

  // --- JUST HIT A PERFECT SCORE ---
  if (submitted && lastResult?.isPerfect) {
    return (
      <div className="bg-green-900/20 border border-green-800 p-8 rounded-xl text-center">
        <h2 className="text-3xl font-bold text-green-400 mb-4 font-display">🎉 Quest Completed!</h2>
        <p className="text-gray-400 mb-2">Perfect score: {lastResult.score}/{lastResult.total} in {lastResult.attemptNumber} attempt(s).</p>
        <p className="text-xl mb-6">You earned <span className="font-bold text-blue-400 font-mono">{lastResult.xp} XP</span> and <span className="font-bold text-yellow-400 font-mono">{lastResult.gold} Gold</span>.</p>
        <button
          onClick={onExit}
          className="bg-neutral-800 hover:bg-neutral-700 text-white font-bold py-3 px-6 rounded transition-colors"
        >
          Return to Campaign Map
        </button>
      </div>
    );
  }

  return (
    <div className="bg-[#111] border border-[#333] p-8 rounded-xl shadow-2xl">
      <div className="flex justify-between items-center border-b border-neutral-800 pb-4 mb-6">
        <h2 className="text-2xl font-bold text-blue-400 font-display">{questName.replace('_', ' ')}</h2>
        <span className="bg-blue-900/30 text-blue-400 text-xs font-bold px-3 py-1 rounded-full border border-blue-800">
          {safeAttemptsSoFar > 0 ? `ATTEMPT ${safeAttemptsSoFar + 1}` : 'IN PROGRESS'}
        </span>
      </div>

      {/* --- ADD THIS WRAPPER AROUND YOUR MARKDOWN --- */}
      {!hideContent && (
        <div className="prose prose-invert max-w-none mb-10">
          <ReactMarkdown>{content}</ReactMarkdown>
        </div>
      )}
      {quiz.length > 0 ? (
        <div className="border-t border-neutral-800 pt-6">
          <h3 className="text-xl font-bold mb-4 font-display">📝 Quiz: Score a perfect round to claim loot!</h3>

          {submitted && !lastResult?.isPerfect && (
            <div className="bg-red-900/20 border border-red-800 rounded-lg p-4 mb-6 text-red-400">
              <p className="font-bold mb-1">❌ Not quite — {lastResult?.score}/{lastResult?.total} correct.</p>
              <p className="text-sm text-gray-400">No loot awarded this attempt. Review the material above and try again for full credit!</p>
            </div>
          )}

          <div className="space-y-6">
            {quiz.map((q, i) => (
              <div key={i} className="bg-black border border-neutral-800 rounded-lg p-4">
                <p className="font-bold mb-3">{i + 1}. {q.question}</p>
                <div className="space-y-2">
                  {q.options.map((opt) => {
                    const isSelected = selectedAnswers[i] === opt;
                    const showFeedback = submitted;
                    const isCorrectOption = opt === q.correct_answer;
                    let optionStyle = 'border-neutral-700 hover:border-blue-500';
                    if (showFeedback) {
                      if (isCorrectOption) optionStyle = 'border-green-600 bg-green-900/20';
                      else if (isSelected && !isCorrectOption) optionStyle = 'border-red-600 bg-red-900/20';
                    } else if (isSelected) {
                      optionStyle = 'border-blue-500 bg-blue-900/20';
                    }
                    return (
                      <button
                        key={opt}
                        onClick={() => handleSelect(i, opt)}
                        disabled={submitted}
                        className={`w-full text-left p-2 rounded border text-sm transition-colors ${optionStyle}`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 flex justify-end gap-3">
            {submitted ? (
              <button
                onClick={handleRetry}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-8 rounded transition-colors"
              >
                🔁 Try Again
              </button>
            ) : (
              <button
                onClick={handleSubmitQuiz}
                disabled={!allAnswered}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-8 rounded transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                ✅ Submit Quiz
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="mt-8 pt-6 border-t border-neutral-800 flex justify-between items-center">
          <p className="text-sm text-gray-400">No quiz for this module — read the material above.</p>
        </div>
      )}
    </div>
  );
}