import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { CharacterStats, WeeklyData } from '@/hooks/useWeeklyData';
import { logAction } from '@/lib/playerlog';

interface AdminPanelProps {
  currentData: WeeklyData;
  currentSunday: string;
  onUpdateStats: (
    newStats: CharacterStats,
    logs: any,
    purchasedItems?: number,
    masteryCount?: number,
    honorGrants?: number
  ) => void;
}

export default function AdminPanel({ currentData, currentSunday, onUpdateStats }: AdminPanelProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [claims, setClaims] = useState<any[]>([]); // New state for queue
  
  const [jsonPayload, setJsonPayload] = useState(
    typeof currentData.package_data === 'string' 
      ? currentData.package_data 
      : JSON.stringify(currentData.package_data || {}, null, 2)
  );
  
  const [stats, setStats] = useState<CharacterStats>(currentData.character_stats);
  const [deedName, setDeedName] = useState('');
  const [deedGold, setDeedGold] = useState('');

  // Fetch claims on mount
  useEffect(() => {
    const fetchClaims = async () => {
      const { data } = await supabase
        .from('reward_claims')
        .select('*')
        .order('created_at', { ascending: false });
      if (data) setClaims(data);
    };
    fetchClaims();
  }, []);

  const toggleStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'pending' ? 'supplied' : 'pending';
    await supabase.from('reward_claims').update({ status: newStatus }).eq('id', id);
    setClaims(claims.map(c => c.id === id ? { ...c, status: newStatus } : c));
  };

  const handleAwardDeed = () => {
    const amount = Number(deedGold);
    if (!deedName.trim() || !amount || amount <= 0) {
      alert('⚠️ Please enter a deed name and a valid gold amount.');
      return;
    }
    const newStats = { ...currentData.character_stats, gold: currentData.character_stats.gold + amount };
    const newHonorGrants = (currentData.honor_grants || 0) + 1;
    onUpdateStats(newStats, currentData.journal_logs, currentData.purchased_items, currentData.mastery_count, newHonorGrants);
    logAction(currentSunday, 'deed', deedName, 0, amount);
    alert(`✅ Awarded 🪙 ${amount} Gold for: ${deedName}`);
    setDeedName('');
    setDeedGold('');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === '735819') { 
      setIsAuthenticated(true);
    } else {
      alert('❌ Access Denied: Incorrect passcode!');
    }
  };

  const handleSaveJSON = async () => {
    try {
      JSON.parse(jsonPayload);
      const { error } = await supabase
        .from('weekly_packages')
        .update({ package_data: jsonPayload })
        .eq('week_starting_date', currentSunday);
        
      if (error) throw error;
      alert('✅ Quest payload updated successfully! Please refresh the page to load the new map.');
    } catch (err: any) {
      alert(`❌ Invalid JSON or save error: ${err.message}`);
    }
  };

  const handleSaveStats = () => {
    onUpdateStats(stats, currentData.journal_logs);
    alert('✅ Character stats forcefully overwritten!');
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md bg-[#111] border border-red-900/50 p-8 rounded-xl">
        <h2 className="text-xl font-bold mb-4 text-red-500">🔒 Restricted Area</h2>
        <p className="text-sm text-gray-400 mb-6">Enter the master passcode to access the Tatay Dashboard.</p>
        <form onSubmit={handleLogin} className="space-y-4">
          <input 
            type="password" 
            placeholder="Enter passcode..." 
            className="w-full bg-black border border-neutral-700 rounded p-2 focus:border-red-500 outline-none"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit" className="w-full bg-red-900 hover:bg-red-800 text-white font-bold py-2 rounded transition-colors">
            Unlock Admin Panel
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="bg-green-900/20 border border-green-800 p-4 rounded-lg text-green-400 font-bold mb-8">
        🔓 Admin Access Granted
      </div>

      {/* REWARD FULFILLMENT QUEUE */}
      <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
        <h3 className="text-xl font-bold mb-4">📦 Reward Fulfillment Queue</h3>
        <div className="space-y-2">
          {claims.length > 0 ? claims.map((claim) => (
            <div key={claim.id} className="flex justify-between items-center bg-black border border-neutral-800 p-3 rounded-lg">
              <div>
                <p className="font-bold">{claim.item_name}</p>
                <p className="text-xs text-gray-500">{new Date(claim.created_at).toLocaleString()}</p>
              </div>
              <button 
                onClick={() => toggleStatus(claim.id, claim.status)}
                className={`px-3 py-1 rounded text-xs font-bold ${claim.status === 'pending' ? 'bg-yellow-900 text-yellow-300' : 'bg-green-900 text-green-300'}`}
              >
                {claim.status === 'pending' ? 'Mark Supplied' : 'Supplied ✅'}
              </button>
            </div>
          )) : <p className="text-gray-500 text-sm">No pending rewards.</p>}
        </div>
      </div>

      {/* AWARD POINTS FOR DEEDS */}
      <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
        <h3 className="text-xl font-bold mb-4 font-display">🏅 Award Gold for a Good Deed</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="md:col-span-2">
            <label className="block text-xs text-gray-500 mb-1">Name of Deed</label>
            <input type="text" placeholder="e.g. Cleaned the garage" className="w-full bg-black border border-neutral-700 rounded p-2"
              value={deedName} onChange={e => setDeedName(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Gold Coins Amount</label>
            <input type="number" placeholder="e.g. 50" className="w-full bg-black border border-neutral-700 rounded p-2 font-mono text-yellow-500"
              value={deedGold} onChange={e => setDeedGold(e.target.value)} />
          </div>
        </div>
        <button onClick={handleAwardDeed} className="bg-green-700 hover:bg-green-600 font-bold py-2 px-4 rounded transition-colors">
          🎉 Award Gold
        </button>
      </div>

      {/* ... (rest of your existing sections remain the same) ... */}
      
      {/* STATS OVERRIDE */}
      <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
        <h3 className="text-xl font-bold mb-4">⚙️ Manual Stat Override</h3>
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-xs text-gray-500 mb-1">Level</label>
            <input type="number" className="w-full bg-black border border-neutral-700 rounded p-2 font-mono" 
              value={stats.level} onChange={e => setStats({...stats, level: Number(e.target.value)})} />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">XP</label>
            <input type="number" className="w-full bg-black border border-neutral-700 rounded p-2 font-mono" 
              value={stats.xp} onChange={e => setStats({...stats, xp: Number(e.target.value)})} />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Gold</label>
            <input type="number" className="w-full bg-black border border-neutral-700 rounded p-2 text-yellow-500 font-mono" 
              value={stats.gold} onChange={e => setStats({...stats, gold: Number(e.target.value)})} />
          </div>
        </div>
        <button onClick={handleSaveStats} className="bg-blue-600 hover:bg-blue-500 font-bold py-2 px-4 rounded transition-colors">
          Force Save Stats
        </button>
      </div>

      {/* QUIZ ATTEMPTS TRACKER */}
      <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
        <h3 className="text-xl font-bold mb-4 font-display">📊 Quiz Attempts</h3>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {Object.entries(currentData.quiz_attempts || {}).map(([key, count]) => {
            const isQuizMastered = (currentData.mastered_quizzes || []).includes(key);
            return (
              <div key={key} className="flex justify-between items-center bg-black border border-neutral-800 p-3 rounded-lg">
                <span className="font-bold">{key.replace('_', ' - ')}</span>
                <span className="flex items-center gap-3">
                  <span className="text-sm text-gray-400 font-mono">{count} attempt{count !== 1 ? 's' : ''}</span>
                  {isQuizMastered ? (
                    <span className="text-xs font-bold text-green-400 uppercase">✅ Mastered</span>
                  ) : (
                    <span className="text-xs font-bold text-gray-500 uppercase">In Progress</span>
                  )}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* JOURNAL LEDGER */}
      <div className="bg-[#111] border border-neutral-800 p-6 rounded-xl">
        <h3 className="text-xl font-bold mb-4">📜 Journal Ledger</h3>
        <div className="space-y-4 max-h-96 overflow-y-auto">
           {Object.entries(currentData.journal_logs || {}).map(([date, entry]) => (
            <div key={date} className="bg-black p-4 rounded border border-neutral-800">
               <div className="text-blue-400 font-bold">{date}</div>
               <p className="text-sm text-gray-300">⚔️ {entry.done_today}</p>
            </div>
           ))}
        </div>
      </div>

      {/* JSON PAYLOAD INJECTOR */}
      <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
        <h3 className="text-xl font-bold mb-2">📜 Inject Weekly Quest Payload</h3>
        <textarea 
          className="w-full h-40 bg-black border border-neutral-700 rounded p-4 font-mono text-xs mb-4"
          value={jsonPayload}
          onChange={(e) => setJsonPayload(e.target.value)}
        />
        <button onClick={handleSaveJSON} className="bg-red-800 hover:bg-red-700 font-bold py-3 px-6 rounded w-full">
          ⚠️ OVERWRITE WEEKLY DATABASE
        </button>
      </div>
    </div>
  );
}